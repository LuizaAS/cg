Compilado no terminal do linux com o comando g++ -o Lista1ex3 Lista1ex3.c -lglut -lGLU -lGL -lm

exercicio 3
Alem do + e - testar as letras r,g,b,R,G,B,c no teclado